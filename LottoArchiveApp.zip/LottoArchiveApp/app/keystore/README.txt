Inserisci qui il file lotto_keystore.jks (verrà creato automaticamente dallo script in /scripts)
